function checkNumber(number) {
  try {
    if (number > 10 && number <= 20) {
      console.log("The number is smaller");

    } else if (number > 21 && number <= 40) {
      console.log("The number is little bigger");

    } else if (number > 41) {
      throw new Error("Your number is more than 41");
    }

  } catch (err) {
    console.log("Error:", err.message);

  } finally {
    console.log("this will always execute");
  }
}

// Test cases
console.log("number = 15");
checkNumber(15);

console.log("\nnumber = 30 ");
checkNumber(30);

console.log("\nnumber = 50 ");
checkNumber(50);