// ============ PART 1: Array Operations ============

// 1. cities array with 3 cities
let cities = ["Mumbai", "Bangalore", "Hyderabad"];

// 2. Add two more cities at the end
cities.push("Pune", "Jaipur");

// 3. Print length and all elements
console.log("Length:", cities.length);
console.log("Cities:", cities);

// 4. Add "Delhi" as first element
cities.unshift("Delhi");

// 5. Add "Chennai" as second element
cities.splice(1, 0, "Chennai");

// 6. Add "Kolkata" as last element
cities.push("Kolkata");

// 7. Pop two times
cities.pop();
cities.pop();

// 8. Print length and all elements
console.log("\nAfter modifications:");
console.log("Length:", cities.length);
console.log("Cities:", cities);


// ============ PART 2: Spread Operator ============

const arr1 = ["Hello", "World"];
const arr2 = [1, 3, 9, 5, 4, 9, 6];

// arr3 = copy of arr1 + arr2 combined
const arr3 = [...arr1, ...arr2];

const arr4 = ['a', 'j', 't', 'r', 'f'];

// arr5 = copy of arr3 + arr4 combined
const arr5 = [...arr3, ...arr4];

console.log("\narr1:", arr1);
console.log("arr2:", arr2);
console.log("arr3 (arr1 + arr2):", arr3);
console.log("arr4:", arr4);
console.log("arr5 (arr3 + arr4):", arr5);