let arr = [34, 78, 12, 11, 67, 55, 42, 89, 60];

// Filter even numbers, then multiply each by 2
const even_arr = arr.filter(num => num % 2 === 0).map(num => num * 2);

// Filter odd numbers, then multiply each by 3
const odd_arr = arr.filter(num => num % 2 !== 0).map(num => num * 3);

console.log("Original array:", arr);

console.log("\nEven numbers * 2:");
console.log("Filtered:", arr.filter(num => num % 2 === 0));
console.log("Result:  ", even_arr);

console.log("\nOdd numbers * 3:");
console.log("Filtered:", arr.filter(num => num % 2 !== 0));
console.log("Result:  ", odd_arr);