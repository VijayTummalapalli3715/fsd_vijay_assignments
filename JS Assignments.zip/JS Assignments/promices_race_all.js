// 6 Promises 
const p1 = new Promise((resolve)         => resolve(10));
const p2 = new Promise((resolve)         => resolve(20));
const p3 = new Promise((resolve)         => resolve(30));
const p4 = new Promise((_, reject)       => reject(40));
const p5 = new Promise((resolve)         => resolve(50));
const p6 = new Promise((_, reject)       => reject(60));


// (1) Promise.all — order: p5,p2,p3,p1,p6,p4 
// .all waits for ALL to resolve; if ANY rejects → goes to catch
// p6 and p4 are rejected, so .all will fail

Promise.all([p5, p2, p3, p1, p6, p4])
  .then(values => {
    console.log("(1) Promise.all resolved:", values);
  })
  .catch(err => {
    console.log("(1) Promise.all rejected with first rejection:", err);
  });


// (2) Promise.race — order: p5,p2,p3,p1,p6,p4 
// .race returns the FIRST settled promise (resolve or reject)
// All are already settled → p5 wins (first in array)

Promise.race([p5, p2, p3, p1, p6, p4])
  .then(value => {
    console.log("(2) Promise.race winner (first settled):", value);
  })
  .catch(err => {
    console.log("(2) Promise.race first settled was rejection:", err);
  });


// (3) Promise.any — order: p5,p2,p3,p1,p6,p4 
// .any returns FIRST resolved promise (ignores rejections)
// p5 is first and resolves → returns 50

Promise.any([p5, p2, p3, p1, p6, p4])
  .then(value => {
    console.log("(3) Promise.any first resolved:", value);
  })
  .catch(err => {
    console.log("(3) Promise.any all rejected:", err);
  });


// (4) Promise.all with .catch 
// Same as (1) but showing .catch explicitly again for clarity

Promise.all([p5, p2, p3, p1, p6, p4])
  .then(values => {
    console.log("(4) Promise.all with .catch — resolved:", values);
  })
  .catch(err => {
    console.log("(4) Promise.all with .catch — caught error:", err);
  });