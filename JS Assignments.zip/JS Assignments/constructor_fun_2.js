// Constructor Function
function Product(name, price, discount) {
  this.name = name;
  this.price = price;
  this.discount = discount;

  this.display = function () {
    const discountedPrice = this.price - (this.price * this.discount) / 100;
    console.log(`Product: ${this.name}`);
    console.log(`Actual Price: ${this.price}`);
    console.log(`Discounted Price: ${discountedPrice}`);
    console.log("----------------------------");
  };
}

// 4 Objects - one for each product
const watch  = new Product("Watch",  5000,  10);
const ledTV  = new Product("LED TV", 10000, 20);
const oven   = new Product("Oven",   20000, 30);
const shoes  = new Product("Shoes",  8000,  5);

// Call display on each
watch.display();
ledTV.display();
oven.display();
shoes.display();