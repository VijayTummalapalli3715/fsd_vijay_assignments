class SI {
  constructor(principal, ROI, time) {
    this._principal = principal;
    this._ROI = ROI;
    this._time = time;
  }

  // Getter methods
  get principal() { return this._principal; }
  get ROI() { return this._ROI; }
  get time() { return this._time; }

  // Setter methods
  set principal(value) { this._principal = value; }
  set ROI(value) { this._ROI = value; }
  set time(value) { this._time = value; }

  // Calculate Simple Interest
  calculate() {
    return (this._principal * this._ROI * this._time) / 100;
  }
}

// 1. Create first object and return SI
const loan = new SI(10000, 5, 2);
console.log("Initial SI:", loan.calculate());

// 2. Getter and Setter demo
console.log("Principal:", loan.principal);
console.log("ROI:", loan.ROI);
console.log("Time:", loan.time);

// 3. Change time = 3 yrs and ROI = 3%, return SI again
loan.time = 3;
loan.ROI = 3;
console.log("Updated SI:", loan.calculate());