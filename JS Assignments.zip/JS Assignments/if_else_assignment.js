const age  = 78;
const age1 = 82;

function checkAge(a) {
  if (a > 20 && a < 30) {
    console.log(`Age ${a}: you are still younger`);
  } else if (a > 31 && a < 50) {
    console.log(`Age ${a}: you are becoming older`);
  } else if (a > 51 && a < 80) {
    console.log(`Age ${a}: you are very old`);
  } else if (a > 81) {
    console.log(`Age ${a}: you are not a valid user`);
  } else {
    console.log(`Age ${a}: age does not fall in any range`);
  }
}

checkAge(age);   // 78
checkAge(age1);  // 82