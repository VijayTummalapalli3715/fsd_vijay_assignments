// ============ 4 Promises ============

const promise1 = new Promise((resolve) => resolve("Hello"));
const promise2 = new Promise((resolve) => resolve("You are learning"));
const promise3 = new Promise((resolve) => resolve("Javascript"));
const promise4 = new Promise((_, reject) => reject("Bye"));


// PART 1: async function - print Javascript, Hello, You are learning 

async function printMessages() {
  const p3 = await promise3;  // "Javascript" - first
  const p1 = await promise1;  // "Hello"       - second
  const p2 = await promise2;  // "You are learning" - third

  console.log(p3);
  console.log(p1);
  console.log(p2);
}

printMessages();


// PART 2: doCode() with try-catch-finally 

// (a) if promise2 is getting returned
async function doCode_a() {
  try {
    const result = await promise2;
    console.log("try (promise2):", result);
  } catch (err) {
    console.log("catch:", err);
  } finally {
    console.log("finally block always runs");
  }
}

// (b) if promise4 is getting returned (rejected)
async function doCode_b() {
  try {
    const result = await promise4;
    console.log("try (promise4):", result);
  } catch (err) {
    console.log("catch (promise4 rejected):", err);
  } finally {
    console.log("finally block always runs");
  }
}

doCode_a();
doCode_b();