// 1. Create a Map of 6 employees (key = employee id, value = name)
const employees = new Map();
employees.set(1, "Vijay");
employees.set(2, "Pratyusha");
employees.set(3, "Chandana");
employees.set(4, "Ajay");
employees.set(5, "Harsha");
employees.set(6, "Bhavika");

console.log("1. Initial Map:");
console.log(employees);

// 2. Delete 5th employee
employees.delete(5);
console.log("\n2. After deleting employee 5:");
console.log(employees);

// 3. Add two more employees
employees.set(7, "Sreeja");
employees.set(8, "Jigeesha");
console.log("\n3. After adding employees 7 and 8:");
console.log(employees);

// 4. Check whether 4th employee is there or not
console.log("\n4. Is employee 4 present?", employees.has(4));

// 5. Check whether 11th employee is there or not
console.log("5. Is employee 11 present?", employees.has(11));

// 6. Fetch and print all employee IDs (keys)
console.log("\n6. All Employee IDs:");
employees.forEach((name, id) => console.log("ID:", id));

// 7. Fetch and print all employee names (values)
console.log("\n7. All Employee Names:");
employees.forEach((name, id) => console.log("Name:", name));

// 8. Fetch and print 8th and 3rd employee
console.log("\n8. Employee 8:", employees.get(8));
console.log("   Employee 3:", employees.get(3));

// 9. Delete all data from the map
employees.clear();
console.log("\n9. After clearing all data:");
console.log("Map size:", employees.size);
console.log(employees);