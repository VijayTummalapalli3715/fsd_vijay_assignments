// ============ Parent Class: Vehicle ============
class Vehicle {
  #capacity;                          // private field

  constructor(name, capacity = 4000) {
    this.name     = name;
    this.#capacity = capacity;
  }

  startEngine() {
    console.log(`${this.name} can start and has capacity of ${this.#capacity}`);
  }

  stopEngine() {
    console.log(`${this.name} can stop and has capacity of ${this.#capacity}`);
  }

  run() {
    console.log(`${this.name} can run on manual mode`);
  }

  static brake() {
    console.log('we are calling static method');
  }

  callCapacity() {
    console.log(`${this.name} has this much ${this.#capacity} capacity`);
  }
}


// ============ Child Class: TwoWheeler ============
class TwoWheeler extends Vehicle {
  constructor(name, capacity) {
    super(name, capacity);            // pass to Vehicle constructor
    this.tyre   = 2;
    this.engine = '3000cc';
  }

  display() {
    console.log("\n--- 2-Wheeler ---");
    console.log("Tyre   :", this.tyre);
    console.log("Engine :", this.engine);
    this.startEngine();
    this.stopEngine();
    this.run();
    this.callCapacity();
    Vehicle.brake();                  // static method via class name
  }
}


// ============ Child Class: ThreeWheeler ============
class ThreeWheeler extends Vehicle {
  constructor(name, capacity) {
    super(name, capacity);
    this.tyre   = 3;
    this.engine = '6000cc';
  }

  display() {
    console.log("\n--- 3-Wheeler ---");
    console.log("Tyre   :", this.tyre);
    console.log("Engine :", this.engine);
    this.startEngine();
    this.stopEngine();
    this.run();
    this.callCapacity();
    Vehicle.brake();
  }
}


// ============ Objects ============
const bike = new TwoWheeler("Bike", 3000);
bike.display();

const auto = new ThreeWheeler("Auto", 6000);
auto.display();