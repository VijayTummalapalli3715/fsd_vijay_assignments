// 1. Normal Function 
function simpleInterest(P, ROI, T) {
  return (P * ROI * T) / 100;
}
console.log("Normal Function SI:", simpleInterest(10000, 5, 2));


// 2. Function Expression 
const simpleInterest2 = function(P, ROI, T) {
  return (P * ROI * T) / 100;
};
console.log("Function Expression SI:", simpleInterest2(10000, 5, 2));


// 3. Arrow Function 
const simpleInterest3 = (P, ROI, T) => (P * ROI * T) / 100;

console.log("Arrow Function SI:", simpleInterest3(10000, 5, 2));