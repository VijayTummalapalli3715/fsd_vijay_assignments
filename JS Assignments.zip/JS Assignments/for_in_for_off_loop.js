let products = [
  {
    name: 'HyperV Projector',
    cost: 2500,
    shipping: 50
  },
  {
    name: 'Vision Cable',
    cost: 10,
    shipping: 0
  },
  {
    name: 'LED screen',
    cost: 5000,
    shipping: 10
  }
];

products.forEach(product => {

  // Output 1: Full sentence
  console.log(
    `This ${product.name} is costing you ${product.cost} with shipping charges extra as ${product.shipping}`
  );

  // Output 2: Short details
  console.log(`${product.name} --> ${product.cost + product.shipping}`);

  console.log("----------------------------");
});