const fruits = ["Apple", "Orange", "Pear", "Kiwi", "Banana", "Melon", "Strawberry", "Mango", "Chiku", "Grapes", "Small-grapes"];

// (1) Even index fruits (0, 2, 4, 6, 8, 10)
console.log("Even index fruits:");
fruits.forEach((fruit, index) => {
  if (index % 2 === 0) console.log(`[${index}] ${fruit}`);
});

// (2) Odd index fruits (1, 3, 5, 7, 9)
console.log("\nOdd index fruits:");
fruits.forEach((fruit, index) => {
  if (index % 2 !== 0) console.log(`[${index}] ${fruit}`);
});

// (3) Multiple of 3 index fruits (0, 3, 6, 9)
console.log("\nMultiple of 3 index fruits:");
fruits.forEach((fruit, index) => {
  if (index % 3 === 0) console.log(`[${index}] ${fruit}`);
});

// (4) 1st, 6th and last fruits together
console.log("\n1st, 6th and Last fruits:");
console.log(fruits[0], fruits[5], fruits[fruits.length - 1]);