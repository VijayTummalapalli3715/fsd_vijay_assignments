// Cart arrays for each user type
const normalCart = [200, 300, 250, 120, 400];
const premiumCart = [100, 400, 550, 100, 400];
const goldenCart = [300, 370, 350, 130, 450];

// Discount rates
const normalDiscount = 5 / 100;
const premiumDiscount = 15 / 100;
const goldenDiscount = 20 / 100;

// Function to calculate discounted prices using forEach
function applyDiscount(cart, discount) {
  const discountedCart = [];
  cart.forEach(price => {
    discountedCart.push(price - price * discount);
  });
  return discountedCart;
}

// Discounted price arrays
const normalDiscounted = applyDiscount(normalCart, normalDiscount);
const premiumDiscounted = applyDiscount(premiumCart, premiumDiscount);
const goldenDiscounted = applyDiscount(goldenCart, goldenDiscount);

console.log("Normal (5% off):", normalDiscounted);
console.log("Premium (15% off):", premiumDiscounted);
console.log("Golden (20% off):", goldenDiscounted);