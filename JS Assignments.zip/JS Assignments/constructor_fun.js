// Constructor Function: Student
function Student(student_name, student_age, student_gender) {
  this.student_name   = student_name;
  this.student_age    = student_age;
  this.student_gender = student_gender;
}

// Create 3 objects
const obj1 = new Student('Pankaj', 23, 'Male');
const obj2 = new Student('Reena', 25, 'Female');
const obj3 = new Student('Rajeev', 26, 'Male');

// 1. Print all member variables using the objects
console.log("--- Student Details ---");
console.log(obj1.student_name, obj1.student_age, obj1.student_gender);
console.log(obj2.student_name, obj2.student_age, obj2.student_gender);
console.log(obj3.student_name, obj3.student_age, obj3.student_gender);

// 2. Add two new properties to the prototype
//    (so all existing objects automatically get them)
Student.prototype.branch  = 'CSE';
Student.prototype.college = 'ABC';

// 3. Call college and branch using the existing objects
console.log("\n--- College & Branch ---");
console.log(obj1.student_name, "| Branch:", obj1.branch, "| College:", obj1.college);
console.log(obj2.student_name, "| Branch:", obj2.branch, "| College:", obj2.college);
console.log(obj3.student_name, "| Branch:", obj3.branch, "| College:", obj3.college);