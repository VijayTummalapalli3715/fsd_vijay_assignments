// area() returns 50 
function area() {
  const length = 5;
  const breadth = 10;
  return length * breadth;  // 50
}

// perimeter() returns 30
function perimeter() {
  const length = 5;
  const breadth = 10;
  return 2 * (length + breadth);  // 30
}

// Default parameters: b=20, c=b*area(), d=c+perimeter()
function calculate(a, b = 20, c = b * area(), d = c + perimeter()) {
  return a + b + c + d;
}

// Call 1: calculate(20)
// a=20, b=20, c=20*50=1000, d=1000+30=1030
console.log("calculate(20)=", calculate(20));

// Call 2: calculate(40, 50, 70, 60)
// all defaults overridden: a=40, b=50, c=70, d=60
console.log("calculate(40,50,70,60)=", calculate(40, 50, 70, 60));

// Call 3: calculate(40, 50)
// a=40, b=50, c=50*50=2500, d=2500+30=2530
console.log("calculate(40, 50)=", calculate(40, 50));