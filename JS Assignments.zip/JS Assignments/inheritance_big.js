// Parent Class: Product 
class Product {
  constructor(prod_name, price, discount) {
    this.prod_name = prod_name;
    this.price     = price;
    this.discount  = discount;
  }

  discountedPrice() {
    const newPrice = this.price - (this.price * this.discount) / 100;
    console.log(`Discounted Price of ${this.prod_name}: ${newPrice}`);
  }
}

// Child Class: ProductBrand 
class ProductBrand extends Product {
  constructor(prod_name, price, discount, brand) {
    super(prod_name, price, discount);  // pass to Product constructor
    this.brand = brand;
  }

  details() {
    console.log(
      `Product: ${this.prod_name} | Price: ${this.price} | Brand: ${this.brand}`
    );
  }
}


// 4 Objects of ProductBrand 
const watch = new ProductBrand("Watch",  5000,  10, "Titan");
const ledTV = new ProductBrand("LED TV", 10000, 20, "Samsung");
const oven  = new ProductBrand("Oven",   20000, 30, "LG");
const shoes = new ProductBrand("Shoes",  8000,  5,  "Nike");

const allProducts = [watch, ledTV, oven, shoes];

// 3. Call details() on each object
console.log("========= Product Details =========");
allProducts.forEach(p => p.details());

// 4. Call discountedPrice() on each object
console.log("\n======= Discounted Prices =========");
allProducts.forEach(p => p.discountedPrice());