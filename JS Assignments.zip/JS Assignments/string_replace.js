const str = "Java Is open source language and Javascript is scripting language. java Is very user-friendly and easy to use";

console.log("Original:\n", str);

// 1 Replace only FIRST "Java" (exact case) with "Python"
const result1 = str.replace("Java", "Python");
console.log("\n1. Replace first 'Java' with 'Python':\n", result1);

// 2 Replace ALL words starting with "java" (case-insensitive) with "python"
//     \b = word boundary, /gi = global + case-insensitive
const result2 = str.replace(/\bjava\w*/gi, "python");
console.log("\n2. Replace all words starting with 'java' with 'python':\n", result2);

// 3 Replace ALL exact "Java" (case-sensitive) with "Hello"
const result3 = str.replace(/Java/g, "Hello");
console.log("\n3. Replace all 'Java' (case-sensitive) with 'Hello':\n", result3);

// 4 Replace ALL "is" (case-insensitive) with "are"
const result4 = str.replace(/\bis\b/gi, "are");
console.log("\n4. Replace all 'is' (case-insensitive) with 'are':\n", result4);