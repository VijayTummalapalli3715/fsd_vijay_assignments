// multiply two numbers
function multiple(a, b) {
  console.log(`Multiple: ${a} * ${b} = ${a * b}`);
}

// add two numbers, then call multiple as callback
function add(a, b, callback) {
  console.log(`Add: ${a} + ${b} = ${a + b}`);
  callback(a, b);
}

// area of rectangle, called after 3 secs, then calls add as callback
function area(l, w, callback) {
  setTimeout(() => {
    console.log(`Area: ${l} * ${w} = ${l * w}`);
    callback(l, w, multiple);
  }, 3000);
}

// Start the chain
area(10, 20, add);